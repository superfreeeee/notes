package cn.superfree.demo4.constant;

public class U {
}
