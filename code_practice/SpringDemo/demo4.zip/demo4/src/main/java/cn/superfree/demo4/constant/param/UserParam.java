package cn.superfree.demo4.constant.param;

import lombok.Data;

@Data
public class UserParam {

  private String name;

  private int age;
}
